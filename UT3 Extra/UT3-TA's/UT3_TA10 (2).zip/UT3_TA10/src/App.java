import java.util.Arrays;
import java.util.LinkedList;

public class App {
    public static void main(String[] args) {

        // Ruta del archivo a leer
        String pathString = "src/suc1.txt";

        // Llamada al método leerArchivo de ManejadorArchivosGenerico
        String[] listita = ManejadorArchivosGenerico.leerArchivo(pathString);
        LinkedList<String> linkedList = new LinkedList<>(Arrays.asList(listita));

        // Imprimir el contenido del archivo leído
        // for(String linea:linkedList) {
        //     System.out.println(linea);
        // }
        
        //EJERCICIO 1
        System.out.println(Sucursal.countSucursales(linkedList));
        //RESPUESTA: 107

        System.out.println("------------------------------------------");

        //EJERCICIO 2
        System.out.println(Sucursal.deleteSucursal("Chicago", linkedList));
        Sucursal.printSucursales(linkedList);

        //EJERCICIO 3
        // Ruta del archivo a leer
        String pathString2 = "src/suc2.txt";

        // Llamada al método leerArchivo de ManejadorArchivosGenerico
        String[] listita2 = ManejadorArchivosGenerico.leerArchivo(pathString2);
        LinkedList<String> linkedList2 = new LinkedList<>(Arrays.asList(listita2));

        System.out.println(Sucursal.deleteSucursal("Tokio", linkedList2));
        Sucursal.printSucursales(linkedList2);


        //EJERCICIO 4
        // Ruta del archivo a leer
        String pathString3 = "src/suc3.txt";

        // Llamada al método leerArchivo de ManejadorArchivosGenerico
        String[] listita3 = ManejadorArchivosGenerico.leerArchivo(pathString3);
        LinkedList<String> linkedList3 = new LinkedList<>(Arrays.asList(listita3));

        Sucursal.printSucursales(linkedList3);
        //RESPUESTA: Montreal,Caracas,Tulsa,Mobile,Vancouver



        // System.out.println("------------------------------------------");
        // //Sucursal.printSucursales(linkedList);
        // Sucursal.addSucursal("SucursalPrueba", linkedList);
        // Sucursal.printSucursales(linkedList);
        // System.out.println();
        // System.out.println("------------------------------------------");
        // System.out.println(Sucursal.deleteSucursal("Dubai", linkedList));
        // Sucursal.printSucursales(linkedList);

        // System.out.println(Sucursal.searchSucursal("Dubai", linkedList));

        // System.out.println();
        // System.out.println("------------------------------------------");

        // System.out.println(Sucursal.countSucursales(linkedList));

        // System.out.println(Sucursal.isEmpty(linkedList));

        //listita.addSucursal()
    }
}
