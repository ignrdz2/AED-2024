import java.util.LinkedList;

public class Sucursal {

    // AGREGAR SUCURSAL
    public static String addSucursal(String sucursal, LinkedList<String> listita) {

        LinkedList<String> lista = listita;

        if (!lista.isEmpty()) {
            lista.add(sucursal);
        } else {
            return "No se ha podido agregado correctamente " + sucursal + " a la lista!";
        }

        return "Se ha agregado correctamente " + sucursal + " a la lista!";
    }

    // BUSCAR SUCURSAL
    public static LinkedList searchSucursal(String sucursal, LinkedList<String> listita) {

        LinkedList<String> lista = listita;
        LinkedList<String> res = new LinkedList<>();

        if (lista.isEmpty()) {
            return res;
        }

        for (String i : listita) {
            if (i.equals(sucursal)) {
                res.add(i);
            }
        }
        return res;
    }

    // ELIMINAR SUCURSAL
    public static String deleteSucursal(String sucursal, LinkedList<String> listita) {

        LinkedList<String> lista = listita;

        if (lista.isEmpty()) {
            return "La lista esta vacia, no se puede eliminar nada!";
        }

        for (String i : listita) {
            if (i.equals(sucursal)) {
                listita.remove(i);
            }
        }
        return "Se eliminaron todos las sucursales llamadas: " + sucursal;

    }

    // LISTAR SUCURSAL
    public static void printSucursales(LinkedList<String> listita) {

        LinkedList<String> lista = listita;

        if (lista.isEmpty()) {
            System.out.println("La lista esta vacia!");
        }

        for (String i : listita) {
            System.out.print(i + ",");
        }

    }

    // LISTAR SUCURSAL
    public static int countSucursales(LinkedList<String> listita) {

        LinkedList<String> lista = listita;
        int contador = 0;

        if (lista.isEmpty()) {
            return 0;
        }

        for (String i : listita) {
            contador++;
        }

        return contador;
    }

    // LISTA VACIA?
    public static boolean isEmpty(LinkedList<String> listita) {

        LinkedList<String> lista = listita;

        if (lista.isEmpty()) {
            return true;
        } else {
            return false;
        }

    }
}
