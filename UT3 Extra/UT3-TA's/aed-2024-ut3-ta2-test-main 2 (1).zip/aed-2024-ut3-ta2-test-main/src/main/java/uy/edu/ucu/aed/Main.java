package uy.edu.ucu.aed;

/**
 *
 * @author abadie
 */
public class Main {
    
    public static void main(String[] args){
        // TODO: 
        /**
         * Instanciar almacen
         * Agregar: productos y cantidades (altas.txt)
         * Emitir listado de productos y cantidades
         * Emitir valor de stock de todo el almacen
         * Vender: restar stock de productos indicado en ventas.txt
         * Emitir valor de stock de todo el almacen
         **/
        // System.err.println("TBD");

        Lista<Integer> listita = new Lista<>();
        listita.insertar(1, 9);
        listita.insertar(2, 8);
        listita.insertar(3, 7);
        listita.insertar(4, 6);
        listita.insertar(5, 5);

        System.out.println(listita.imprimir());
        listita.imprimir();

        System.out.println(listita.buscar(6));

    }
}
