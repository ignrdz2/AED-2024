package uy.edu.ucu.aed;

public class Lista<T> implements ILista<T> {

    private Nodo<T> primero;

    public Lista() {
        primero = null;
    }

    @Override
    public void insertar(T dato, Comparable clave) {

        Nodo<T> nuevoNodo = new Nodo<T>(clave, dato);

        if (esVacia()) {
            primero = nuevoNodo;
        } else {
            Nodo<T> aux = primero;
            while (aux.getSiguiente() != null) {
                aux = aux.getSiguiente();
            }
            aux.setSiguiente(nuevoNodo);
        }
    }

    @Override
    public T buscar(Comparable clave) {
        if(esVacia()){
            return null;
        } else {
            Nodo<T> auxNodo = primero;
            while (auxNodo != null) {
                if (auxNodo.getEtiqueta().equals(clave)) {
                    return auxNodo.getDato();
                }
                auxNodo = auxNodo.getSiguiente();
            }
        }
        return null;
    }

    @Override
    public boolean eliminar(Comparable clave) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'eliminar'");
    }

    @Override
    public String imprimir() {
        return imprimir(", ");
    }

    @Override
    public String imprimir(String separador) {
        Nodo<T> nodoActual = primero;
        String result = "";

        while (nodoActual != null) {
            result += nodoActual.getEtiqueta() + separador;
            nodoActual = nodoActual.getSiguiente();
        }

        return result;
    }

    @Override
    public int cantElementos() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'cantElementos'");
    }

    @Override
    public boolean esVacia() {
        return primero == null;
    }

    @Override
    public void setPrimero(Nodo<T> unNodo) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setPrimero'");
    }


    // implementar los metodos indicados en la interfaz
}
