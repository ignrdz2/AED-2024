package com.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ContadorPalabras {
    String palabra;
    String[] numbers = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
    String[] vocals = {"a", "e", "i", "o", "u"};

    public ContadorPalabras(){

    }
    
    public String[] obtenerLineas (String archivo) {
        ArrayList<String> listaLineasArchivo = new ArrayList<String>();
        try {
            FileReader fr = new FileReader(archivo);
            BufferedReader br = new BufferedReader(fr);
            String linea;
            while ((linea = br.readLine()) != null) {
                listaLineasArchivo.add(linea);
            }
            br.close();
            fr.close();
        } catch (IOException e) {
            System.out.println("Error al leer el archivo " + archivo);
            e.printStackTrace();
        }
        return listaLineasArchivo.toArray(new String[0]);
    }

    public int cantPalabras (String[] lineasArchivo) {
        int count = 0;
        for (String linea : lineasArchivo) {
            count += contarPalabras(linea);
        }
        return count;
    }

    public int GetConsonants(String frase){
        int count = 0;

        for(char letra : frase.toCharArray()){
            if(Character.isLetter(letra) && !Arrays.asList(vocals).contains(String.valueOf(letra))) {
                count++;
            }
        }

        return count;
    }

    public int GetVocals(String frase) {
        int count = 0;
        for (char letra : frase.toCharArray()) {
            if (Arrays.asList(vocals).contains(String.valueOf(letra))) {
                count++;
            }
        }
        return count;
    }

    public int contarPalabras(String frase){
        int count = 0;
        boolean isWord = false;
        boolean containsAlphabetic = false;
    
        for (char letra : frase.toCharArray()) {
            if (letra == ' ') {
                if (isWord && containsAlphabetic) {
                    count++;
                }
                isWord = false;
                containsAlphabetic = false;
            } else {
                isWord = true;
                if (Character.isLetter(letra)) {
                    containsAlphabetic = true;
                }
            }
        }
    
        // If the last word doesn't end with a space, count it
        if (isWord && containsAlphabetic) {
            count++;
        }
    
        return count;
    }

    public int palabraMayoresX(String frase, int x) {
        int count = 0;
        boolean isWord = false;
        int longitudPalabra = 0;

        for (int i =0; i < frase.length(); i++) {
            char c = frase.charAt(i);
            if (Character.isLetter(c)) {
                isWord = true;
                longitudPalabra++;
            } else if (isWord){
                if (longitudPalabra > x) {
                    count++;
                }
                longitudPalabra = 0;
                isWord = false;
            }
        }
        if (isWord && longitudPalabra > x) {
            count++;
        }
        return count;
    }

    public boolean isNumber(char letra){
        if(!Arrays.asList(numbers).contains(String.valueOf(letra)) ){
            return false;
        }
        return true;
    }




}
