public class Main {
    public static void main(String[] args) {
        long primo1 = 13;
        long primo2 = 97;
        long noPrimo1 = 15;
        long noPrimo2 = 99;
        int fact1 = 5;
        int fact2 = 6;

        System.out.println("Factorial:");
        
        System.out.println(UtilMath.factorial(fact1));
        System.out.println(UtilMath.factorial(fact2));

        System.out.println(" ");

        System.out.println("Suma par o impar:");

        System.out.println(UtilMath.sumaParOImpar(primo1));
        System.out.println(UtilMath.sumaParOImpar(primo2));
        System.out.println(UtilMath.sumaParOImpar(noPrimo1));
        System.out.println(UtilMath.sumaParOImpar(noPrimo2));

    }
}