public class UtilMath {
    public static int factorial(int num)
    {
        int factorial = 1;
        for (; num > 0; num--)
        {
            factorial *= num;

        }
        return factorial;
    }
   public static long sumaParOImpar (long n) {
        long suma = 0;
        long i = 0;
        if (esPrimo(n)) {
            while (i <= n) {
                if (i % 2 == 0) {
                    suma += i;
                }
                i++;
            }
        } else {
            do {
                if (i % 2 != 0) {
                    suma += i;
                }
                i++;
            } while (i <= n);
        }
        return suma;
   }
    public static boolean esPrimo(long n) {
        boolean prime = true;
        for (long i = 3; i <= Math.sqrt(n); i += 2)
            if (n % i == 0) {
                prime = false;
                break;
            }
        if (( n%2 !=0 && prime && n > 2) || n == 2) {
            return true;
        } else {
            return false;
        }
    }
}
