// Ejercicio 1
public class pruebaAtributos {
    // int 0 = 0; <identifier> expected
    // int -cero = 0; <identifier> expected
    // int while = 0; <identifier> expected
    // int !cero = 0; <identifier> expected


    public static void main(String[] args) {
        //System.out.println(0);
        //System.out.println(-cero);
        //System.out.println(while);
        //System.out.println(!cero);
        // System.out.println(cero); cannot find symbol - symbol:   variable cero - location: class pruebaAtributos

    }
}

// Ejercicio 2
class ArithmeticDemo {
    public static void main (String[] args){

        /* 1)
        int result = 1 + 2;
        System.out.println(result);
        result--; //result = result - 1
        System.out.println(result);
        result *= 2; // result = result * 2
        System.out.println(result);
        result /= 2; // result = result / 2
        System.out.println(result);
        result += 8; // result = result + 8
        result %= 7; // result = result % 7
        System.out.println(result);
        */

        /* 2)
        int a = 5;
        int i = 3;
        a+=++i;
        // a = a + (i + 1)
        System.out.println(a);
        */
    }
}
// 3)
class PrePostDemo {
    public static void main(String[] args){
        /*int i = 3;
        i++;
        System.out.println(i);
        ++i;
        System.out.println(i);
        System.out.println(++i); // Primero le incrementa 1 y despues lo imprime
        System.out.println(i++); // Primero lo imprime y despues le incrementa 1
        System.out.println(i);*/
    }
}

// Ejercicio 3
/*
Identifique los tipos de las siguientes sentencias:
1. aValue = 8933.234; - b
2. aValue++; - a
3. System.out.println("Hello World!"); - d
4. Bicycle myBike = new Bicycle(); - c
a) Incremento - 2
b) Asignación - 1
c) Creación de objeto - 4
d) Invocación de método - 3
 */


// Ejercicio 4
/*
1. Considere el siguiente código:
if (aNumber >= 0)
    if (aNumber == 0)
        System.out.println("first string");
else
    System.out.println("second string");
System.out.println("third string");

a) ¿Qué salida cree que producirá el código si aNumber es 3?
"second string" "third string"

b) Cree un programa de prueba que contenga el código anterior; haga que aNumber
valga 3. ¿Cuál es la salida del programa? ¿Es la que usted predijo? Explique por qué la
salida es la que es, o, en otras palabras, ¿cuál es el flujo de control del código
provisto?
Salida del programa:
    second string
    third string
Entra en el primer if aNumber es mayor que cero entonces entra en el segundo if pero no es igual a cero y pasa al else
imprime second string y despes sale de los id e imprime third string


c) Utilizando sólo espacios y saltos de línea, reformatee el código para hacer que el flujo
de control sea más fácil de entender.

if (aNumber >= 0)
    if (aNumber == 0)
        System.out.println("first string");
    else
        System.out.println("second string");
System.out.println("third string");

d) Utilice llaves, { y } para aclarar aún más el código

if (aNumber >= 0) {
    if (aNumber == 0) {
        System.out.println("first string");
    } else {
        System.out.println("second string");
    }
}
System.out.println("third string");
 */