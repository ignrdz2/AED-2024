package uy.edu.ucu.aed;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

// import org.junit.After;
// import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for implemented methods.
 */
public class Parcial1Test_Junit4 
{
    @Test
    public void testObtenerHojas() {
        TArbolBB<String> arbol = new TArbolBB<>();
        arbol.insertar(2, "B");
        arbol.insertar(1, "A");
        arbol.insertar(3, "C");

        List<String> hojas = arbol.obtenerHojas();

        assertEquals(2, hojas.size());
        assertTrue(hojas.contains("A"));
        assertTrue(hojas.contains("C"));
    }

    @Test
    public void testObtenerNodosInternos() {
        TArbolBB<String> arbol = new TArbolBB<>();
        arbol.insertar(2, "B");
        arbol.insertar(1, "A");
        arbol.insertar(3, "C");

        List<String> nodosInternos = arbol.obtenerNodosInternos();

        assertEquals(1, nodosInternos.size());
        assertTrue(nodosInternos.contains("B"));
    }
}
