

import java.util.LinkedList;


public class TArbolTrie implements IArbolTrie {

    private TNodoTrie raiz;

    @Override
    public void insertar(String palabra) {
        TNodoTrie actual = raiz;
        for(int i = 0; i < palabra.length(); i++){
            char ch = palabra.charAt(i);
            if(!actual.contiene(ch)){
                actual.put(ch, new TNodoTrie());
            }
            actual = actual.get(ch);
        }
        actual.setFin(true);
    }

    @Override
    public void imprimir() {
        if (raiz != null) {
            raiz.imprimir();
        }
    }

    @Override
    public int buscar(String palabra) {
        int count = 0;
        TNodoTrie nodo = raiz;
        for (int i = 0; i < palabra.length(); i++) {
            char ch = palabra.charAt(i);
            if (!nodo.contiene(ch)) {
                return 0; // La cadena no está en el Trie.
            }
            nodo = nodo.get(ch);
            count++;
        }
        // La cadena está en el Trie y puede ser una palabra completa o un prefijo.
        return count;
    }

    @Override
    private void predecir(String s, String prefijo, LinkedList<String> palabras, TNodoTrie nodo) {
        if (nodo != null) {
            if (nodo.esPalabra) {
                palabras.add(prefijo + s);
            }
            for (int c = 0; c < CANT_CHR_ABECEDARIO; c++) {
                if (nodo.hijos[c] != null) {
                    predecir(s + (char) (c + 'a'), prefijo, palabras, nodo.hijos[c]);
                }
            }
        }
    }

    public void predecir(String prefijo, LinkedList<String> palabras) {
        TNodoTrie nodo = buscarNodoTrie(prefijo);
        predecir("", prefijo, palabras, nodo);
    }
    
    
}
