import java.util.ArrayList;
import java.util.List;

public class ej {
    public List<String> buscarPalabrasXpref(String prefijo){
        List<String> palabras = new ArrayList<>();
        Nodo nodo = raiz;
        for(int i = 0; i < prefijo.length(); i++){
            char ch = prefijo.charAt(i);
            if(!nodo.contiene(ch)){
                return palabras;
            }
            nodo = nodo.get(ch);
        }
        buscarPalabrasXpref(nodo, new StringBuilder(prefijo), palabras);
        return palabras;
    }
    private void buscarPalabrasXpref(Nodo nodo, StringBuilder prefijo, List<String> palabras){
        if(nodo.esFin()){
            palabras.add(prefijo.toString());
        }
        if(nodo.esHoja()){
            return;
        }
        for(char ch = 'a'; ch <= 'z'; ch++){
            if(nodo.contiene(ch)){
                prefijo.append(ch);
                buscarPalabrasXpref(nodo.get(ch), prefijo, palabras);
                prefijo.deleteCharAt(prefijo.length() - 1);
            }
        }
    }
}
